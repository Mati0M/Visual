#include "BSTree.h"
#include <iostream>
#include <fstream>
#include <string>
BSTree::BSTree() {
    korzen = nullptr;
}
BSTree::~BSTree() {
    wyczysc();
}
void BSTree::dodaj(int wartosc) {
    korzen = dodajHelper(korzen, wartosc);
}
void BSTree::usun(int wartosc) {
    korzen = usunHelper(korzen, wartosc);
}
void BSTree::wyczysc() {
    wyczyscHelper(korzen);
    korzen = nullptr;
}
void BSTree::znajdzSciezke(int wartosc) {
    std::cout << "Sciezka do " << wartosc << ": ";
    if (znajdzSciezkeHelper(korzen, wartosc) == false) {
        std::cout << "Nie znaleziono elementu.";
    }
    std::cout << std::endl;
}
void BSTree::zapiszDoTekstowego(const std::string& nazwaPliku) {
    std::ofstream plikWyjsciowy(nazwaPliku);

    if (!plikWyjsciowy.is_open()) {
        std::cout << "Blad: Nie mozna otworzyc pliku do zapisu!" << std::endl;
        return;
    }

    zapiszHelper(korzen, plikWyjsciowy);

    plikWyjsciowy.close();
    std::cout << "Zapisano drzewo do pliku: " << nazwaPliku << std::endl;
}
void BSTree::wyswietl_preorder() {
    std::cout << "Preorder: [ ";
    preorderHelper(korzen);
    std::cout << "]" << std::endl;
}
void BSTree::wyswietl_inorder() {
    std::cout << "Inorder: [ ";
    inorderHelper(korzen);
    std::cout << "]" << std::endl;
}
void BSTree::wyswietl_postorder() {
    std::cout << "Postorder: [ ";
    postorderHelper(korzen);
    std::cout << "]" << std::endl;
}
void BSTree::wyswietlGraficznie() {
    std::cout << "--- Struktura drzewa (obrocone o 90 stopni) ---" << std::endl;
    wyswietlGraficznieHelper(korzen, "", false);
    std::cout << "-----------------------------------------------" << std::endl;
}
BSTree::Wezel* BSTree::dodajHelper(Wezel* wezel, int wartosc) {
    if (wezel == nullptr) {
        return new Wezel(wartosc);
    }

    if (wartosc < wezel->dane) {
        wezel->lewy = dodajHelper(wezel->lewy, wartosc);
    } else if (wartosc > wezel->dane) {
        wezel->prawy = dodajHelper(wezel->prawy, wartosc);
    }

    return wezel;
}
BSTree::Wezel* BSTree::usunHelper(Wezel* wezel, int wartosc) {
    if (wezel == nullptr) {
        std::cout << "Nie znaleziono elementu " << wartosc << " do usuniecia." << std::endl;
        return nullptr;
    }

    if (wartosc < wezel->dane) {
        wezel->lewy = usunHelper(wezel->lewy, wartosc);
    } else if (wartosc > wezel->dane) {
        wezel->prawy = usunHelper(wezel->prawy, wartosc);
    } 
    else {
        if (wezel->lewy == nullptr && wezel->prawy == nullptr) {
            delete wezel;
            return nullptr;
        }
        else if (wezel->lewy == nullptr) {
            Wezel* temp = wezel->prawy;
            delete wezel;
            return temp;
        }
        else if (wezel->prawy == nullptr) {
            Wezel* temp = wezel->lewy;
            delete wezel;
            return temp;
        }
        else {
            Wezel* nastepnik = znajdzMin(wezel->prawy);
            wezel->dane = nastepnik->dane;
            wezel->prawy = usunHelper(wezel->prawy, nastepnik->dane);
        }
    }
    return wezel;
}
BSTree::Wezel* BSTree::znajdzMin(Wezel* wezel) {
    Wezel* obecny = wezel;
    while (obecny != nullptr && obecny->lewy != nullptr) {
        obecny = obecny->lewy;
    }
    return obecny;
}
void BSTree::wyczyscHelper(Wezel* wezel) {
    if (wezel == nullptr) {
        return;
    }
    wyczyscHelper(wezel->lewy);
    wyczyscHelper(wezel->prawy);
    delete wezel;
}
void BSTree::preorderHelper(Wezel* wezel) {
    if (wezel == nullptr) return;
    std::cout << wezel->dane << " ";
    preorderHelper(wezel->lewy);
    preorderHelper(wezel->prawy);
}
void BSTree::inorderHelper(Wezel* wezel) {
    if (wezel == nullptr) return;
    inorderHelper(wezel->lewy);
    std::cout << wezel->dane << " ";
    inorderHelper(wezel->prawy);
}
void BSTree::postorderHelper(Wezel* wezel) {
    if (wezel == nullptr) return;
    postorderHelper(wezel->lewy);
    postorderHelper(wezel->prawy);
    std::cout << wezel->dane << " ";
}
bool BSTree::znajdzSciezkeHelper(Wezel* wezel, int wartosc) {
    if (wezel == nullptr) {
        return false;
    }

    std::cout << wezel->dane;

    if (wezel->dane == wartosc) {
        std::cout << " (Znaleziono)";
        return true;
    }

    std::cout << " -> ";
    if (wartosc < wezel->dane) {
        return znajdzSciezkeHelper(wezel->lewy, wartosc);
    } else {
        return znajdzSciezkeHelper(wezel->prawy, wartosc);
    }
}
void BSTree::zapiszHelper(Wezel* wezel, std::ostream& plik) {
    if (wezel == nullptr) {
        return;
    }
    zapiszHelper(wezel->lewy, plik);
    plik << wezel->dane << "\n";
    zapiszHelper(wezel->prawy, plik);
}
void BSTree::wyswietlGraficznieHelper(Wezel* wezel, std::string wciecie, bool czyPrawy) {
    if (wezel == nullptr) {
        return;
    }

    wyswietlGraficznieHelper(wezel->prawy, wciecie + "    ", true);

    std::cout << wciecie;
    if (czyPrawy) {
        std::cout << "/---";
    } else {
        std::cout << "\\---";
    }
    std::cout << wezel->dane << std::endl;

    wyswietlGraficznieHelper(wezel->lewy, wciecie + "    ", false);
}