#ifndef BSTREE_H
#define BSTREE_H

#include <string>
#include <iosfwd>

class FileManager;
class BSTree {
friend class FileManager;

private:
    struct Wezel {
        int dane;
        Wezel* lewy;
        Wezel* prawy;
        Wezel(int wartosc) {
            dane = wartosc;
            lewy = nullptr;
            prawy = nullptr;
        }
    };
    Wezel* korzen;
    Wezel* dodajHelper(Wezel* wezel, int wartosc);
    Wezel* usunHelper(Wezel* wezel, int wartosc);
    Wezel* znajdzMin(Wezel* wezel);
    void wyczyscHelper(Wezel* wezel);
    void preorderHelper(Wezel* wezel);
    void inorderHelper(Wezel* wezel);
    void postorderHelper(Wezel* wezel);
    bool znajdzSciezkeHelper(Wezel* wezel, int wartosc);
    void zapiszHelper(Wezel* wezel, std::ostream& plik);
    void wyswietlGraficznieHelper(Wezel* wezel, std::string wciecie, bool czyPrawy);


public:
    BSTree();
    ~BSTree();
    void dodaj(int wartosc);
    void usun(int wartosc);
    void wyczysc();
    void znajdzSciezke(int wartosc);
    void zapiszDoTekstowego(const std::string& nazwaPliku);
    void wyswietl_preorder();
    void wyswietl_inorder();
    void wyswietl_postorder();
    void wyswietlGraficznie();

}; 

#endif // BSTREE_H