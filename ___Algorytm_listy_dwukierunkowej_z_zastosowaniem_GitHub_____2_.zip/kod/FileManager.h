#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <string>
#include "BSTree.h" 
#include <iosfwd>
class FileManager {

private:
    void zapiszBinarnieHelper(BSTree::Wezel* wezel, std::ostream& plik);

public:
    void wczytajTekstowyDoDrzewa(BSTree& drzewo, const std::string& nazwaPliku);
    void zapiszBinarnie(BSTree& drzewo, const std::string& nazwaPliku);
    BSTree wczytajBinarnie(const std::string& nazwaPliku);

};

#endif // FILEMANAGER_H