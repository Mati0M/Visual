#include "FileManager.h"
#include <fstream>
#include <iostream>
void FileManager::wczytajTekstowyDoDrzewa(BSTree& drzewo, const std::string& nazwaPliku) {
    std::ifstream plikWejsciowy(nazwaPliku);

    if (!plikWejsciowy.is_open()) {
        std::cout << "Blad: Nie mozna otworzyc pliku: " << nazwaPliku << std::endl;
        return;
    }

    int liczba;
    while (plikWejsciowy >> liczba) {
        drzewo.dodaj(liczba);
    }

void FileManager::zapiszBinarnie(BSTree& drzewo, const std::string& nazwaPliku) {
    std::ofstream plikWyjsciowy(nazwaPliku, std::ios::binary);

    if (!plikWyjsciowy.is_open()) {
        std::cout << "Blad: Nie mozna otworzyc pliku binarnego: " << nazwaPliku << std::endl;
        return;
    }

    zapiszBinarnieHelper(drzewo.korzen, plikWyjsciowy);   

    plikWyjsciowy.close();
    std::cout << "Zapisano drzewo binarnie do " << nazwaPliku << "." << std::endl;
}
void FileManager::zapiszBinarnieHelper(BSTree::Wezel* wezel, std::ostream& plik) {
    if (wezel == nullptr) {
        return;
    }

    plik.write( (char*)&(wezel->dane), sizeof(int) );
    zapiszBinarnieHelper(wezel->lewy, plik);
    zapiszBinarnieHelper(wezel->prawy, plik);
}
BSTree FileManager::wczytajBinarnie(const std::string& nazwaPliku) {
    
    BSTree noweDrzewo;

    std::ifstream plikWejsciowy(nazwaPliku, std::ios::binary);

    if (!plikWejsciowy.is_open()) {
        std::cout << "Blad: Nie mozna otworzyc pliku binarnego: " << nazwaPliku << std::endl;
        return noweDrzewo;
    }

    int liczba;
    
    while ( plikWejsciowy.read( (char*)&liczba, sizeof(int)) ) {
        noweDrzewo.dodaj(liczba);
    }

    plikWejsciowy.close();
    std::cout << "Wczytano drzewo z pliku binarnego " << nazwaPliku << "." << std::endl;
    
    return noweDrzewo;
}